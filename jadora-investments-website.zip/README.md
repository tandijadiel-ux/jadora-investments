# Jadora Investments website

Open `index.html` in a browser to preview the site. The site uses plain HTML, CSS, and JavaScript; no build step is required. The supplied logo is in `assets/jadora-logo.png`.

## Edit the site
- `index.html` contains the page structure, service copy, and contact details.
- `styles.css` contains the color palette, layout, responsive styles, and motion effects.
- `script.js` contains the mobile navigation and scroll reveal behavior.
- Replace `assets/jadora-logo.png` to use another logo file.
